function sum(num1, num2) {
  return numb1 + num2;
}

const square = function (num) {
  return num * num;
};

const cube = (num) => {
  return num * num * num;
};

const PI = 3.14;

module.exports = {
  sum,
  square,
  cube,
  PI,
  student: ["Ali", "Hamza", "Fazi"],
};

// module.exports = {
//   sum: sum,
//   square: square,
//   cube: cube,
//   PI: PI,
// };

// module.exports.sum = sum;
// module.exports.square = square;
// module.exports.cube = cube;
// module.exports.PI = PI;
